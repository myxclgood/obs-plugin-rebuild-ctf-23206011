param(
    [string]$Configuration = "Release",
    [string]$OpenCV_DIR = $env:OpenCV_DIR
)

$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$build = Join-Path $root "build-msvc"
New-Item -ItemType Directory -Force -Path $build | Out-Null

$args = @("-S", $root, "-B", $build, "-A", "x64", "-DCMAKE_BUILD_TYPE=$Configuration")
if ($OpenCV_DIR) { $args += "-DOpenCV_DIR=$OpenCV_DIR" }

cmake @args
cmake --build $build --config $Configuration

Write-Host ""
Write-Host "Output:"
Write-Host "  $build\$Configuration\obs_plugin.dll"
