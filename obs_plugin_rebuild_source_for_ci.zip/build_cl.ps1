param(
    [string]$Configuration = "Release",
    [string]$OpenCVInclude = $env:OpenCV_INCLUDE,
    [string]$OpenCVLib = $env:OpenCV_LIB,
    [string]$OpenCVWorldLib = $env:OpenCV_WORLD_LIB,
    [string]$OnnxRuntimeInclude = $env:ONNXRUNTIME_INCLUDE_DIR,
    [string]$OnnxRuntimeLib = $env:ONNXRUNTIME_LIB_DIR,
    [switch]$WithOnnxRuntime,
    [switch]$WithDirectML
)

$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$outDir = Join-Path $root "build-cl"
New-Item -ItemType Directory -Force -Path $outDir | Out-Null

if (-not $OpenCVInclude -or -not $OpenCVLib -or -not $OpenCVWorldLib) {
    throw "Set OpenCVInclude, OpenCVLib and OpenCVWorldLib, e.g. -OpenCVInclude C:\opencv\build\include -OpenCVLib C:\opencv\build\x64\vc16\lib -OpenCVWorldLib opencv_world480.lib"
}

$flags = @("/nologo", "/std:c++17", "/EHsc", "/LD", "/DWIN32_LEAN_AND_MEAN", "/DNOMINMAX", "/DOBS_REBUILD_WITH_OPENCV=1", "/I$OpenCVInclude")
$extraLibs = @()
if ($WithOnnxRuntime) {
    if (-not $OnnxRuntimeInclude -or -not $OnnxRuntimeLib) { throw "Set OnnxRuntimeInclude and OnnxRuntimeLib when using -WithOnnxRuntime" }
    $flags += @("/DOBS_REBUILD_WITH_ONNXRUNTIME=1", "/I$OnnxRuntimeInclude")
    $extraLibs += @("/LIBPATH:$OnnxRuntimeLib", "onnxruntime.lib")
} else {
    $flags += @("/DOBS_REBUILD_WITH_ONNXRUNTIME=0")
}
if ($WithDirectML) { $flags += @("/DOBS_REBUILD_WITH_DIRECTML=1") } else { $flags += @("/DOBS_REBUILD_WITH_DIRECTML=0") }
if ($Configuration -ieq "Debug") { $flags += @("/Zi", "/Od", "/MDd") } else { $flags += @("/O2", "/MD") }

$sources = @(
    "src\plugin.cpp",
    "src\config.cpp",
    "src\capture_gdi.cpp",
    "src\capture_dxgi.cpp",
    "src\capture_window.cpp",
    "src\capture_manager.cpp",
    "src\detector_opencv_dnn.cpp",
    "src\detector_onnxruntime.cpp",
    "src\detector.cpp",
    "src\mouse_controller.cpp",
    "src\worker.cpp"
) | ForEach-Object { Join-Path $root $_ }

& cl @flags $sources `
    "/Fe:$outDir\obs_plugin.dll" `
    "/Fo:$outDir\" `
    /link "/LIBPATH:$OpenCVLib" $OpenCVWorldLib user32.lib gdi32.lib d3d11.lib dxgi.lib $extraLibs "/DEF:$(Join-Path $root 'src\plugin.def')" "/OUT:$outDir\obs_plugin.dll"

Write-Host ""
Write-Host "Output:"
Write-Host "  $outDir\obs_plugin.dll"


