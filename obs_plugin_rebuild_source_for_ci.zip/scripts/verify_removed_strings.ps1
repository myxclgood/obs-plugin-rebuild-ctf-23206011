param(
    [Parameter(Mandatory = $true)]
    [string]$DllPath
)

$ErrorActionPreference = "Stop"

if (!(Test-Path -LiteralPath $DllPath)) {
    throw "DLL not found: $DllPath"
}

$bytes = [System.IO.File]::ReadAllBytes((Resolve-Path -LiteralPath $DllPath))
$ascii = [System.Text.Encoding]::ASCII.GetString($bytes)

$removed = @(
    "sniper_rifle_parameter_settings",
    "sniper_delay_compensation_time",
    "sniper_aim_key",
    "sniper_aim_mode",
    "gun_control_settings",
    "aim_key_for_gun_control",
    "recoil_key_value",
    "weapon_icon_recognition_mode",
    "weapon_icon_path",
    "weapon_csv_path",
    "normal_gun_control_value",
    "recoil_offset"
)

$hits = @()
foreach ($s in $removed) {
    if ($ascii.Contains($s)) {
        $hits += $s
    }
}

if ($hits.Count) {
    Write-Host "Found removed strings:" -ForegroundColor Red
    $hits | ForEach-Object { Write-Host "  $_" -ForegroundColor Red }
    exit 1
}

Write-Host "OK: no removed feature strings found in $DllPath" -ForegroundColor Green

