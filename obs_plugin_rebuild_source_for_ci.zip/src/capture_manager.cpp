#include "capture_manager.h"

#if OBS_REBUILD_WITH_OPENCV
cv::Mat CaptureManager::capture_bgr(const RuntimeConfig &config)
{
    if (config.screenshot_mode == 2) {
        cv::Mat frame = dxgi_.capture_bgr(16);
        if (!frame.empty())
            return frame;
    }
    if (config.screenshot_mode == 1) {
        cv::Mat frame = window_.capture_foreground_bgr();
        if (!frame.empty())
            return frame;
    }
    return gdi_.capture_fullscreen_bgr();
}
#endif
