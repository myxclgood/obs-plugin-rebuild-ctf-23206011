#pragma once

#include "config.h"
#include <optional>
#include <string>

#if OBS_REBUILD_WITH_OPENCV
#include <opencv2/core.hpp>
#include <opencv2/dnn.hpp>
#else
namespace cv { class Mat; struct Rect; }
#endif

struct DetectionResult {
    int class_id = -1;
    float confidence = 0.0f;
#if OBS_REBUILD_WITH_OPENCV
    cv::Rect box;
#endif
};

class DetectorOpenCVDnn {
public:
    bool configure(const RuntimeConfig &config);
    bool ready() const { return ready_; }

#if OBS_REBUILD_WITH_OPENCV
    std::optional<DetectionResult> detect(const cv::Mat &bgr, const RuntimeConfig &config);
#endif

private:
    std::string loaded_model_;
    bool ready_ = false;
#if OBS_REBUILD_WITH_OPENCV
    cv::dnn::Net net_;
#endif
};
