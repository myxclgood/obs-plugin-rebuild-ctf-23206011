#pragma once

#include "config.h"
#include "capture_gdi.h"
#include "capture_dxgi.h"
#include "capture_window.h"

class CaptureManager {
public:
#if OBS_REBUILD_WITH_OPENCV
    cv::Mat capture_bgr(const RuntimeConfig &config);
#endif
private:
    GdiScreenCapturer gdi_;
    DxgiScreenCapturer dxgi_;
    WindowCapturer window_;
};
