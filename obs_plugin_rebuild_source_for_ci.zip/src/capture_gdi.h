#pragma once

#if OBS_REBUILD_WITH_OPENCV
#include <opencv2/core.hpp>
#endif

class GdiScreenCapturer {
public:
#if OBS_REBUILD_WITH_OPENCV
    cv::Mat capture_fullscreen_bgr() const;
#endif
};
