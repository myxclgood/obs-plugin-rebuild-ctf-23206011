#include "detector.h"

#if OBS_REBUILD_WITH_OPENCV
bool DetectorRuntime::configure(const RuntimeConfig &config)
{
#if OBS_REBUILD_WITH_ONNXRUNTIME
    prefer_ort_ = (config.inference_method == 0 || config.inference_method == 1) && ort_.configure(config);
    if (prefer_ort_)
        return true;
#endif
    prefer_ort_ = false;
    return opencv_.configure(config);
}

bool DetectorRuntime::ready() const
{
    return prefer_ort_ ? ort_.ready() : opencv_.ready();
}

std::optional<DetectionResult> DetectorRuntime::detect(const cv::Mat &bgr, const RuntimeConfig &config)
{
#if OBS_REBUILD_WITH_ONNXRUNTIME
    if (prefer_ort_) {
        auto r = ort_.detect(bgr, config);
        if (r)
            return r;
    }
#endif
    return opencv_.detect(bgr, config);
}
#endif
