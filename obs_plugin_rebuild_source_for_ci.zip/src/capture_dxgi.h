#pragma once

#if OBS_REBUILD_WITH_OPENCV
#include <opencv2/core.hpp>
#endif

#include <wrl/client.h>
#include <d3d11.h>
#include <dxgi1_2.h>

class DxgiScreenCapturer {
public:
    DxgiScreenCapturer() = default;
    ~DxgiScreenCapturer() = default;

#if OBS_REBUILD_WITH_OPENCV
    cv::Mat capture_bgr(unsigned timeout_ms = 16);
#endif

private:
    bool init();
    void reset();

    Microsoft::WRL::ComPtr<ID3D11Device> device_;
    Microsoft::WRL::ComPtr<ID3D11DeviceContext> context_;
    Microsoft::WRL::ComPtr<IDXGIOutputDuplication> duplication_;
    Microsoft::WRL::ComPtr<ID3D11Texture2D> staging_;
    int width_ = 0;
    int height_ = 0;
};
