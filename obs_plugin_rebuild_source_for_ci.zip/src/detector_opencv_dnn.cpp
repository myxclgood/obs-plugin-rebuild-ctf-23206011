#include "detector_opencv_dnn.h"

#include <algorithm>
#include <cmath>
#include <filesystem>

#if OBS_REBUILD_WITH_OPENCV
#include <opencv2/imgproc.hpp>
#endif

bool DetectorOpenCVDnn::configure(const RuntimeConfig &config)
{
#if OBS_REBUILD_WITH_OPENCV
    if (config.weights_path.empty() || !std::filesystem::exists(config.weights_path)) {
        ready_ = false;
        loaded_model_.clear();
        net_ = cv::dnn::Net();
        return false;
    }

    if (ready_ && loaded_model_ == config.weights_path)
        return true;

    try {
        net_ = cv::dnn::readNetFromONNX(config.weights_path);
        net_.setPreferableBackend(cv::dnn::DNN_BACKEND_OPENCV);
        net_.setPreferableTarget(cv::dnn::DNN_TARGET_CPU);
        loaded_model_ = config.weights_path;
        ready_ = true;
        return true;
    } catch (...) {
        ready_ = false;
        loaded_model_.clear();
        net_ = cv::dnn::Net();
        return false;
    }
#else
    (void)config;
    ready_ = false;
    return false;
#endif
}

#if OBS_REBUILD_WITH_OPENCV
std::optional<DetectionResult> DetectorOpenCVDnn::detect(const cv::Mat &bgr, const RuntimeConfig &config)
{
    if (!ready_ || bgr.empty())
        return std::nullopt;

    constexpr int input_size = 640;
    cv::Mat blob;
    cv::dnn::blobFromImage(bgr, blob, 1.0 / 255.0, cv::Size(input_size, input_size), cv::Scalar(), true, false);
    net_.setInput(blob);

    std::vector<cv::Mat> outs;
    try {
        net_.forward(outs, net_.getUnconnectedOutLayersNames());
    } catch (...) {
        return std::nullopt;
    }
    if (outs.empty())
        return std::nullopt;

    cv::Mat out = outs[0];
    if (out.dims != 3)
        return std::nullopt;

    int d1 = out.size[1];
    int d2 = out.size[2];
    bool transposed = false;
    int rows = d1;
    int cols = d2;
    if (d1 < d2 && d1 <= 256) { // YOLOv8 often [1, 84, N]
        transposed = true;
        rows = d2;
        cols = d1;
    }
    if (cols < 5)
        return std::nullopt;

    float xscale = static_cast<float>(bgr.cols) / static_cast<float>(input_size);
    float yscale = static_cast<float>(bgr.rows) / static_cast<float>(input_size);

    DetectionResult best;
    float best_score = 0.0f;
    const float threshold = static_cast<float>(config.conf_threshold);

    auto value_at = [&](int r, int c) -> float {
        if (transposed)
            return out.ptr<float>(0, c)[r];
        return out.ptr<float>(0, r)[c];
    };

    for (int r = 0; r < rows; ++r) {
        float cx = value_at(r, 0);
        float cy = value_at(r, 1);
        float w = value_at(r, 2);
        float h = value_at(r, 3);

        float objectness = 1.0f;
        int class_begin = 4;
        if (cols > 6) {
            float maybe_obj = value_at(r, 4);
            if (maybe_obj >= 0.0f && maybe_obj <= 1.0f) {
                objectness = maybe_obj;
                class_begin = 5;
            }
        }

        int cls = -1;
        float cls_score = 0.0f;
        for (int c = class_begin; c < cols; ++c) {
            float s = value_at(r, c);
            if (s > cls_score) {
                cls_score = s;
                cls = c - class_begin;
            }
        }

        float score = objectness * cls_score;
        if (score < threshold || score <= best_score)
            continue;

        int left = static_cast<int>((cx - w * 0.5f) * xscale);
        int top = static_cast<int>((cy - h * 0.5f) * yscale);
        int bw = static_cast<int>(w * xscale);
        int bh = static_cast<int>(h * yscale);
        best.class_id = cls;
        best.confidence = score;
        best.box = cv::Rect(left, top, bw, bh) & cv::Rect(0, 0, bgr.cols, bgr.rows);
        best_score = score;
    }

    if (best_score <= 0.0f)
        return std::nullopt;
    return best;
}
#endif
