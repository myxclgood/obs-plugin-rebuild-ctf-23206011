#include "mouse_controller.h"

#include <algorithm>
#include <cctype>
#include <cstdio>`r`n#include <cstring>

MouseController::~MouseController()
{
    close_serial();
}

void MouseController::close_serial()
{
    if (serial_ != INVALID_HANDLE_VALUE) {
        CloseHandle(serial_);
        serial_ = INVALID_HANDLE_VALUE;
    }
    opened_port_.clear();
}

bool MouseController::ensure_serial(const std::string &port)
{
    if (port.empty())
        return false;
    if (serial_ != INVALID_HANDLE_VALUE && opened_port_ == port)
        return true;
    close_serial();

    std::string path = port;
    if (path.rfind("\\\\.\\", 0) != 0)
        path = "\\\\.\\" + path;

    serial_ = CreateFileA(path.c_str(), GENERIC_READ | GENERIC_WRITE, 0, nullptr, OPEN_EXISTING, 0, nullptr);
    if (serial_ == INVALID_HANDLE_VALUE)
        return false;

    DCB dcb{};
    dcb.DCBlength = sizeof(dcb);
    if (!GetCommState(serial_, &dcb)) {
        close_serial();
        return false;
    }
    dcb.BaudRate = CBR_115200;
    dcb.ByteSize = 8;
    dcb.Parity = NOPARITY;
    dcb.StopBits = ONESTOPBIT;
    if (!SetCommState(serial_, &dcb)) {
        close_serial();
        return false;
    }

    COMMTIMEOUTS to{};
    to.ReadIntervalTimeout = 20;
    to.ReadTotalTimeoutConstant = 20;
    to.ReadTotalTimeoutMultiplier = 1;
    to.WriteTotalTimeoutConstant = 20;
    to.WriteTotalTimeoutMultiplier = 1;
    SetCommTimeouts(serial_, &to);
    opened_port_ = port;
    return true;
}

bool MouseController::move_kmbox_serial(int dx, int dy, const RuntimeConfig &config)
{
    // 支持用户把 kmbox_vid_pid 填成 COM3 / COM12 这类串口名。
    // 常见 kmbox 文本协议使用 km.move(x,y)；不同固件可在这里替换命令格式。
    std::string port = config.kmbox_vid_pid;
    for (auto &ch : port)
        ch = static_cast<char>(std::toupper(static_cast<unsigned char>(ch)));
    if (port.rfind("COM", 0) != 0)
        return false;
    if (!ensure_serial(port))
        return false;

    char cmd[64]{};
    std::snprintf(cmd, sizeof(cmd), "km.move(%d,%d)\r\n", dx, dy);
    DWORD written = 0;
    return WriteFile(serial_, cmd, static_cast<DWORD>(std::strlen(cmd)), &written, nullptr) && written > 0;
}

bool MouseController::move_sendinput(int dx, int dy)
{
    if (dx == 0 && dy == 0)
        return true;
    INPUT input{};
    input.type = INPUT_MOUSE;
    input.mi.dx = dx;
    input.mi.dy = dy;
    input.mi.dwFlags = MOUSEEVENTF_MOVE;
    return SendInput(1, &input, sizeof(input)) == 1;
}

bool MouseController::move_relative(int dx, int dy, const RuntimeConfig &config)
{
    const int limit = std::max(1, config.mouse_single_movement_distance);
    dx = std::clamp(dx, -limit, limit);
    dy = std::clamp(dy, -limit, limit);

    if (config.mouse_move_method >= 1 && config.mouse_move_method <= 3) {
        if (move_kmbox_serial(dx, dy, config))
            return true;
    }

    // Logitech 私有驱动接口未内置；干净重写版默认回退 SendInput。
    return move_sendinput(dx, dy);
}

