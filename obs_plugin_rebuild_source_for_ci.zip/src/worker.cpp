#include "worker.h"

#include <windows.h>
#include <chrono>
#include <cmath>

AimWorker::~AimWorker()
{
    stop();
}

void AimWorker::update_config(const RuntimeConfig &config)
{
    std::lock_guard<std::mutex> lock(mutex_);
    config_ = config;
    detector_.configure(config_);
}

void AimWorker::start()
{
    bool expected = false;
    if (!running_.compare_exchange_strong(expected, true))
        return;
    thread_ = std::thread(&AimWorker::loop, this);
}

void AimWorker::stop()
{
    bool expected = true;
    if (running_.compare_exchange_strong(expected, false)) {
        if (thread_.joinable())
            thread_.join();
    } else if (thread_.joinable()) {
        thread_.join();
    }
}

bool AimWorker::aim_key_down(const RuntimeConfig &config) const
{
    int key = config.rifle_aim_key_value ? config.rifle_aim_key_value : config.rifle_aim_key_value2;
    if (key <= 0)
        return true;
    return (GetAsyncKeyState(key) & 0x8000) != 0;
}

void AimWorker::loop()
{
#if OBS_REBUILD_WITH_OPENCV
    while (running_.load()) {
        RuntimeConfig cfg;
        {
            std::lock_guard<std::mutex> lock(mutex_);
            cfg = config_;
            detector_.configure(cfg);
        }

        if (!detector_.ready() || !aim_key_down(cfg)) {
            std::this_thread::sleep_for(std::chrono::milliseconds(10));
            continue;
        }

        cv::Mat frame = capturer_.capture_bgr(cfg);
        if (frame.empty()) {
            std::this_thread::sleep_for(std::chrono::milliseconds(30));
            continue;
        }

        auto det = detector_.detect(frame, cfg);
        if (!det || det->box.empty()) {
            std::this_thread::sleep_for(std::chrono::milliseconds(10));
            continue;
        }

        const int screen_cx = frame.cols / 2;
        const int screen_cy = frame.rows / 2;
        const int target_x = det->box.x + det->box.width / 2;
        int target_y = det->box.y + det->box.height / 2;

        // upper/lower_limit 使用百分比近似调整瞄准点。
        double vertical_bias = (cfg.rifle_aim_position_lower_limit - cfg.rifle_aim_position_upper_limit) / 100.0;
        target_y += static_cast<int>(det->box.height * vertical_bias);

        int dx = target_x - screen_cx;
        int dy = target_y - screen_cy;
        if (cfg.rifle_aim_pixel_range > 0) {
            if (std::abs(dx) > cfg.rifle_aim_pixel_range || std::abs(dy) > cfg.rifle_aim_pixel_range) {
                std::this_thread::sleep_for(std::chrono::milliseconds(10));
                continue;
            }
        }

        double speed = cfg.rifle_static_aim_speed <= 0.0 ? 1.0 : cfg.rifle_static_aim_speed;
        double sensitivity = cfg.game_sensitivity <= 0.0 ? 1.0 : cfg.game_sensitivity;
        dx = static_cast<int>(std::round(dx * speed / sensitivity));
        dy = static_cast<int>(std::round(dy * speed / sensitivity));
        mouse_.move_relative(dx, dy, cfg);

        std::this_thread::sleep_for(std::chrono::milliseconds(std::max(1, cfg.rifle_delay_compensation_time)));
    }
#else
    while (running_.load())
        std::this_thread::sleep_for(std::chrono::milliseconds(100));
#endif
}
