#include "config.h"
#include "plugin_api.h"

namespace {

const char *get_string_or_empty(ObsApi &obs, obs_data_t *settings, const char *name)
{
    if (!obs.obs_data_get_string)
        return "";
    const char *s = obs.obs_data_get_string(settings, name);
    return s ? s : "";
}

long long get_int_or(ObsApi &obs, obs_data_t *settings, const char *name, long long fallback)
{
    return obs.obs_data_get_int ? obs.obs_data_get_int(settings, name) : fallback;
}

double get_double_or(ObsApi &obs, obs_data_t *settings, const char *name, double fallback)
{
    return obs.obs_data_get_double ? obs.obs_data_get_double(settings, name) : fallback;
}

bool get_bool_or(ObsApi &obs, obs_data_t *settings, const char *name, bool fallback)
{
    return obs.obs_data_get_bool ? obs.obs_data_get_bool(settings, name) : fallback;
}

} // namespace

RuntimeConfig read_config_from_obs(ObsApi &obs, obs_data_t *settings)
{
    RuntimeConfig c;
    if (!settings)
        return c;

    c.weights_path = get_string_or_empty(obs, settings, "weights_path");
    c.conf_threshold = get_double_or(obs, settings, "conf_threshold", c.conf_threshold);
    c.yoloversion = static_cast<int>(get_int_or(obs, settings, "yoloversion", c.yoloversion));
    c.first_part = static_cast<int>(get_int_or(obs, settings, "first_part", c.first_part));
    c.include_head = static_cast<int>(get_int_or(obs, settings, "include_head", c.include_head));
    c.first_team = static_cast<int>(get_int_or(obs, settings, "first_team", c.first_team));
    c.mouse_move_method = static_cast<int>(get_int_or(obs, settings, "mouse_move_method", c.mouse_move_method));
    c.kmbox_vid_pid = get_string_or_empty(obs, settings, "kmbox_vid_pid");
    c.inference_method = static_cast<int>(get_int_or(obs, settings, "inference_method", c.inference_method));
    c.cpu_threads = static_cast<int>(get_int_or(obs, settings, "cpu_threads", c.cpu_threads));
    c.half_precision = get_bool_or(obs, settings, "half_precision", c.half_precision);
    c.gpu_index = static_cast<int>(get_int_or(obs, settings, "gpu_index", c.gpu_index));
    c.screenshot_mode = static_cast<int>(get_int_or(obs, settings, "screenshot_mode", c.screenshot_mode));
    c.show_detection_window = get_bool_or(obs, settings, "show_detection_window", c.show_detection_window);

    c.game_sensitivity = get_double_or(obs, settings, "game_sensitivity", c.game_sensitivity);
    c.mouse_single_movement_distance = static_cast<int>(get_int_or(obs, settings, "mouse_single_movement_distance", c.mouse_single_movement_distance));
    c.movement_shake_degree = get_double_or(obs, settings, "movement_shake_degree", c.movement_shake_degree);
    c.maximum_lead = static_cast<int>(get_int_or(obs, settings, "maximum_lead", c.maximum_lead));
    c.lead_gear = static_cast<int>(get_int_or(obs, settings, "lead_gear", c.lead_gear));
    c.game_rotation_pixel_count = static_cast<int>(get_int_or(obs, settings, "game_rotation_pixel_count", c.game_rotation_pixel_count));
    c.rotation_measurement_sensitivity = get_double_or(obs, settings, "rotation_measurement_sensitivity", c.rotation_measurement_sensitivity);

    c.rifle_delay_compensation_time = static_cast<int>(get_int_or(obs, settings, "rifle_delay_compensation_time", c.rifle_delay_compensation_time));
    c.rifle_aim_key_value = static_cast<int>(get_int_or(obs, settings, "rifle_aim_key_value", c.rifle_aim_key_value));
    c.rifle_aim_key_value2 = static_cast<int>(get_int_or(obs, settings, "rifle_aim_key_value2", c.rifle_aim_key_value2));
    c.rifle_aim_mode = static_cast<int>(get_int_or(obs, settings, "rifle_aim_mode", c.rifle_aim_mode));
    c.rifle_automatic_fire_interval = static_cast<int>(get_int_or(obs, settings, "rifle_automatic_fire_interval", c.rifle_automatic_fire_interval));
    c.rifle_automatic_fire_judgment_range = get_double_or(obs, settings, "rifle_automatic_fire_judgment_range", c.rifle_automatic_fire_judgment_range);
    c.rifle_aim_pixel_range = static_cast<int>(get_int_or(obs, settings, "rifle_aim_pixel_range", c.rifle_aim_pixel_range));
    c.rifle_aim_position_upper_limit = static_cast<int>(get_int_or(obs, settings, "rifle_aim_position_upper_limit", c.rifle_aim_position_upper_limit));
    c.rifle_aim_position_lower_limit = static_cast<int>(get_int_or(obs, settings, "rifle_aim_position_lower_limit", c.rifle_aim_position_lower_limit));
    c.rifle_aim_position_horizontal_limit = static_cast<int>(get_int_or(obs, settings, "rifle_aim_position_horizontal_limit", c.rifle_aim_position_horizontal_limit));
    c.rifle_static_aim_speed = get_double_or(obs, settings, "rifle_static_aim_speed", c.rifle_static_aim_speed);
    c.rifle_movement_tracking_speed = get_double_or(obs, settings, "rifle_movement_tracking_speed", c.rifle_movement_tracking_speed);
    return c;
}
