#pragma once

#if OBS_REBUILD_WITH_OPENCV
#include <opencv2/core.hpp>
#endif

class WindowCapturer {
public:
#if OBS_REBUILD_WITH_OPENCV
    cv::Mat capture_foreground_bgr() const;
#endif
};
