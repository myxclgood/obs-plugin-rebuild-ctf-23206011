#include "obs_abi_min.h"
#include "plugin_api.h"
#include "config.h"
#include "worker.h"

#include <windows.h>

#include <cstdint>
#include <initializer_list>
#include <mutex>
#include <new>
#include <utility>

namespace {

constexpr std::uint32_t kOriginalModuleVersion = 0x1d010003;
constexpr const char *kSourceId = "obs plugin";
constexpr const char *kSourceName = "obs plugin";

ObsApi g_obs;
void *g_module = nullptr;
std::mutex g_state_mutex;

struct SourceState {
    obs_source_t *source = nullptr;
    RuntimeConfig config;
    AimWorker worker;
};

SourceState *g_active_state = nullptr;

const char *text(const char *key)
{
    return key ? key : "";
}

void add_int_default(obs_data_t *settings, const char *name, long long value)
{
    if (g_obs.obs_data_set_default_int)
        g_obs.obs_data_set_default_int(settings, name, value);
}

void add_bool_default(obs_data_t *settings, const char *name, bool value)
{
    if (g_obs.obs_data_set_default_bool)
        g_obs.obs_data_set_default_bool(settings, name, value);
}

void add_double_default(obs_data_t *settings, const char *name, double value)
{
    if (g_obs.obs_data_set_default_double)
        g_obs.obs_data_set_default_double(settings, name, value);
}

void add_list_int(obs_properties_t *props,
                  const char *name,
                  std::initializer_list<std::pair<const char *, long long>> items)
{
    auto *p = g_obs.obs_properties_add_list(props, name, text(name), OBS_COMBO_TYPE_LIST, OBS_COMBO_FORMAT_INT);
    if (!p)
        return;
    for (const auto &item : items)
        g_obs.obs_property_list_add_int(p, text(item.first), item.second);
}

void add_ms_suffix(obs_property_t *property)
{
    if (g_obs.obs_property_int_set_suffix && property)
        g_obs.obs_property_int_set_suffix(property, " ms");
}

void hide(obs_property_t *property)
{
    if (g_obs.obs_property_set_visible && property)
        g_obs.obs_property_set_visible(property, false);
}

template <typename Builder>
void add_group(obs_properties_t *root, const char *name, Builder builder)
{
    auto *group = g_obs.obs_properties_create();
    if (!group)
        return;
    builder(group);
    g_obs.obs_properties_add_group(root, name, text(name), OBS_GROUP_CHECKABLE, group);
}

SourceState *active_state()
{
    std::lock_guard<std::mutex> lock(g_state_mutex);
    return g_active_state;
}

bool start_button(obs_properties_t *, obs_property_t *, void *)
{
    if (auto *state = active_state())
        state->worker.start();
    return true;
}

bool stop_button(obs_properties_t *, obs_property_t *, void *)
{
    if (auto *state = active_state())
        state->worker.stop();
    return true;
}

bool capture_key_button(obs_properties_t *, obs_property_t *, void *)
{
    // OBS 按钮回调没有可靠 settings 写回句柄；保留按钮入口，实际键值可直接填写隐藏 int 项。
    return true;
}

void build_basic_settings(obs_properties_t *root)
{
    add_group(root, "basic_settings", [](obs_properties_t *p) {
        g_obs.obs_properties_add_float_slider(p, "conf_threshold", text("conf_threshold"), 0.0, 1.0, 0.01);
        g_obs.obs_properties_add_path(p, "weights_path", text("weights_path"), OBS_PATH_FILE, "ONNX (*.onnx);;All files (*.*)", nullptr);

        add_list_int(p, "yoloversion", {{"yolox", 0}, {"yolov5", 1}, {"yolov8", 2}});
        add_list_int(p, "first_part", {{"body", 0}, {"head", 1}});
        add_list_int(p, "include_head", {{"head_included", 0}, {"head_excluded", 1}});
        add_list_int(p, "first_team", {{"Enemy", 0}, {"Teammate", 1}});
        add_list_int(p, "mouse_move_method", {{"Sendinput", 0}, {"kmboxA", 1}, {"kmboxA+", 2}, {"kmboxB", 3}, {"Logitech", 4}});

        g_obs.obs_properties_add_text(p, "kmbox_vid_pid", text("kmbox_vid_pid"), OBS_TEXT_DEFAULT);
        add_list_int(p, "inference_method", {{"CPU", 0}, {"DirectML", 1}});
        g_obs.obs_properties_add_int(p, "cpu_threads", text("cpu_threads"), 1, 64, 1);
        g_obs.obs_properties_add_bool(p, "half_precision", text("half_precision"));
        g_obs.obs_properties_add_int(p, "gpu_index", text("gpu_index"), -1, 16, 1);
        add_list_int(p, "screenshot_mode", {{"Fullscreen", 0}, {"Window", 1}, {"DXGI", 2}});
        g_obs.obs_properties_add_bool(p, "show_detection_window", text("show_detection_window"));
    });
}

void build_global_movement_parameters(obs_properties_t *root)
{
    add_group(root, "global_movement_parameters", [](obs_properties_t *p) {
        g_obs.obs_properties_add_float_slider(p, "game_sensitivity", text("game_sensitivity"), 0.01, 20.0, 0.01);
        g_obs.obs_properties_add_int_slider(p, "mouse_single_movement_distance", text("mouse_single_movement_distance"), 1, 500, 1);
        g_obs.obs_properties_add_float_slider(p, "movement_shake_degree", text("movement_shake_degree"), 0.0, 10.0, 0.01);
        g_obs.obs_properties_add_int_slider(p, "maximum_lead", text("maximum_lead"), 0, 5000, 1);
        g_obs.obs_properties_add_int_slider(p, "lead_gear", text("lead_gear"), 0, 10, 1);
        g_obs.obs_properties_add_int(p, "game_rotation_pixel_count", text("game_rotation_pixel_count"), 1, 20000, 1);
        g_obs.obs_properties_add_float_slider(p, "rotation_measurement_sensitivity", text("rotation_measurement_sensitivity"), 0.01, 20.0, 0.01);
    });
}

void build_rifle_parameter_settings(obs_properties_t *root)
{
    add_group(root, "rifle_parameter_settings", [](obs_properties_t *p) {
        add_ms_suffix(g_obs.obs_properties_add_int_slider(p, "rifle_delay_compensation_time", text("rifle_delay_compensation_time"), 0, 1000, 1));

        g_obs.obs_properties_add_text(p, "rifle_aim_key", text("rifle_aim_key"), OBS_TEXT_INFO);
        hide(g_obs.obs_properties_add_int(p, "rifle_aim_key_value", text("rifle_aim_key_value"), 0, 255, 1));
        g_obs.obs_properties_add_button(p, "capture_key_rifle", text("capture_key"), capture_key_button);

        g_obs.obs_properties_add_text(p, "rifle_aim_key2", text("rifle_aim_key2"), OBS_TEXT_INFO);
        hide(g_obs.obs_properties_add_int(p, "rifle_aim_key_value2", text("rifle_aim_key_value2"), 0, 255, 1));
        g_obs.obs_properties_add_button(p, "capture_key_rifle2", text("capture_key"), capture_key_button);

        add_list_int(p, "rifle_aim_mode", {{"move_once", 0}, {"move_constant", 1}, {"move_and_shot", 2}});
        add_ms_suffix(g_obs.obs_properties_add_int(p, "rifle_automatic_fire_interval", text("rifle_automatic_fire_interval"), 0, 2000, 1));
        g_obs.obs_properties_add_float_slider(p, "rifle_automatic_fire_judgment_range", text("rifle_automatic_fire_judgment_range"), 0.0, 1.0, 0.01);
        g_obs.obs_properties_add_int_slider(p, "rifle_aim_pixel_range", text("rifle_aim_pixel_range"), 0, 1000, 1);
        g_obs.obs_properties_add_int_slider(p, "rifle_aim_position_upper_limit", text("rifle_aim_position_upper_limit"), 0, 100, 1);
        g_obs.obs_properties_add_int_slider(p, "rifle_aim_position_lower_limit", text("rifle_aim_position_lower_limit"), 0, 100, 1);
        g_obs.obs_properties_add_int_slider(p, "rifle_aim_position_horizontal_limit", text("rifle_aim_position_horizontal_limit"), 0, 100, 1);
        g_obs.obs_properties_add_float_slider(p, "rifle_static_aim_speed", text("rifle_static_aim_speed"), 0.0, 100.0, 0.01);
        g_obs.obs_properties_add_float_slider(p, "rifle_movement_tracking_speed", text("rifle_movement_tracking_speed"), 0.0, 100.0, 0.01);
    });
}

void build_start_and_info(obs_properties_t *root)
{
    add_group(root, "start_and_info", [](obs_properties_t *p) {
        g_obs.obs_properties_add_text(p, "rifle_head", text("Ctrl+F1_rifle_aim_head"), OBS_TEXT_INFO);
        g_obs.obs_properties_add_text(p, "rifle_body", text("Ctrl+F2_rifle_aim_body"), OBS_TEXT_INFO);
        g_obs.obs_properties_add_text(p, "aim_enemy", text("HOME+F1_aim_enemy"), OBS_TEXT_INFO);
        g_obs.obs_properties_add_text(p, "aim_teammate", text("HOME+F2_aim_teammate"), OBS_TEXT_INFO);
        g_obs.obs_properties_add_text(p, "aim_all", text("HOME+F3_aim_all"), OBS_TEXT_INFO);
        g_obs.obs_properties_add_text(p, "lead_level", text("HOME+number_lead_level"), OBS_TEXT_INFO);
        g_obs.obs_properties_add_text(p, "measure_gameFOV", text("HOME+PageUp_measure_gameFOV"), OBS_TEXT_INFO);
        g_obs.obs_properties_add_text(p, "measure_aimspeed", text("HOME+PageDown_measure_aimspeed_and_latency"), OBS_TEXT_INFO);

        g_obs.obs_properties_add_button(p, "startbutton", text("Start"), start_button);
        auto *stop = g_obs.obs_properties_add_button(p, "stopbutton", text("Stop"), stop_button);
        hide(stop);
    });
}

void set_defaults(obs_data_t *settings)
{
    g_obs.load();
    add_double_default(settings, "conf_threshold", 0.35);
    add_int_default(settings, "yoloversion", 1);
    add_int_default(settings, "cpu_threads", 3);
    add_bool_default(settings, "half_precision", false);
    add_int_default(settings, "screenshot_mode", 0);

    add_double_default(settings, "game_sensitivity", 1.0);
    add_int_default(settings, "mouse_single_movement_distance", 100);
    add_double_default(settings, "movement_shake_degree", 0.0);
    add_int_default(settings, "maximum_lead", 1000);
    add_int_default(settings, "lead_gear", 0);
    add_int_default(settings, "game_rotation_pixel_count", 3750);
    add_double_default(settings, "rotation_measurement_sensitivity", 1.0);

    add_int_default(settings, "rifle_delay_compensation_time", 20);
    add_int_default(settings, "rifle_aim_mode", 1);
    add_int_default(settings, "rifle_automatic_fire_interval", 80);
    add_double_default(settings, "rifle_automatic_fire_judgment_range", 0.5);
    add_int_default(settings, "rifle_aim_pixel_range", 100);
    add_int_default(settings, "rifle_aim_position_upper_limit", 1);
    add_int_default(settings, "rifle_aim_position_lower_limit", 2);
    add_int_default(settings, "rifle_aim_position_horizontal_limit", 1);
    add_double_default(settings, "rifle_static_aim_speed", 1.0);
    add_double_default(settings, "rifle_movement_tracking_speed", 1.0);
}

obs_properties_t *get_properties(void *)
{
    if (!g_obs.load())
        return nullptr;
    auto *root = g_obs.obs_properties_create();
    if (!root)
        return nullptr;
    build_basic_settings(root);
    build_global_movement_parameters(root);
    build_rifle_parameter_settings(root);
    build_start_and_info(root);
    return root;
}

const char *get_name(void *)
{
    return kSourceName;
}

void *create(obs_data_t *settings, obs_source_t *source)
{
    auto *state = new (std::nothrow) SourceState();
    if (!state)
        return nullptr;
    state->source = source;
    state->config = read_config_from_obs(g_obs, settings);
    state->worker.update_config(state->config);
    {
        std::lock_guard<std::mutex> lock(g_state_mutex);
        g_active_state = state;
    }
    return state;
}

void destroy(void *data)
{
    auto *state = static_cast<SourceState *>(data);
    if (!state)
        return;
    state->worker.stop();
    {
        std::lock_guard<std::mutex> lock(g_state_mutex);
        if (g_active_state == state)
            g_active_state = nullptr;
    }
    delete state;
}

void update(void *data, obs_data_t *settings)
{
    auto *state = static_cast<SourceState *>(data);
    if (!state)
        return;
    state->config = read_config_from_obs(g_obs, settings);
    state->worker.update_config(state->config);
}

std::uint32_t get_width(void *) { return 1; }
std::uint32_t get_height(void *) { return 1; }

obs_source_info_lite g_source_info = {
    kSourceId,
    OBS_SOURCE_TYPE_INPUT,
    OBS_SOURCE_VIDEO,
    get_name,
    create,
    destroy,
    get_width,
    get_height,
    set_defaults,
    get_properties,
    update,
};

} // namespace

extern "C" __declspec(dllexport) bool obs_module_load()
{
    if (!g_obs.load())
        return false;
    g_obs.obs_register_source_s(&g_source_info, sizeof(g_source_info));
    return true;
}

extern "C" __declspec(dllexport) void obs_module_unload()
{
    if (auto *state = active_state())
        state->worker.stop();
}

extern "C" __declspec(dllexport) std::uint32_t obs_module_ver()
{
    return kOriginalModuleVersion;
}

extern "C" __declspec(dllexport) void obs_module_set_pointer(void *module)
{
    g_module = module;
}

extern "C" __declspec(dllexport) void obs_module_set_locale(const char *)
{
}

extern "C" __declspec(dllexport) void obs_module_free_locale()
{
}

extern "C" __declspec(dllexport) const char *obs_module_get_string(const char *lookup_string)
{
    return lookup_string ? lookup_string : "";
}

extern "C" __declspec(dllexport) const char *obs_module_name()
{
    return "obs_plugin_rebuild";
}

extern "C" __declspec(dllexport) const char *obs_module_description()
{
    return "Clean rebuilt OBS ONNX/OpenCV plugin.";
}

extern "C" __declspec(dllexport) const char *obs_module_author()
{
    return "rebuild";
}

