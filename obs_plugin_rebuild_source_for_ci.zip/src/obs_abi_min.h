#pragma once

#include <cstddef>
#include <cstdint>

// 只保留本精简工程需要用到的 libobs ABI 片段。
// 不依赖 OBS SDK / obs.lib，实际函数在运行时从 obs.dll 动态解析。

struct obs_data;
struct obs_source;
struct obs_properties;
struct obs_property;

using obs_data_t = obs_data;
using obs_source_t = obs_source;
using obs_properties_t = obs_properties;
using obs_property_t = obs_property;

enum obs_source_type : int {
    OBS_SOURCE_TYPE_INPUT = 0,
    OBS_SOURCE_TYPE_FILTER = 1,
    OBS_SOURCE_TYPE_TRANSITION = 2,
    OBS_SOURCE_TYPE_SCENE = 3,
};

enum obs_source_output_flags : std::uint32_t {
    OBS_SOURCE_VIDEO = 1u << 0,
    OBS_SOURCE_AUDIO = 1u << 1,
    OBS_SOURCE_ASYNC = 1u << 2,
    OBS_SOURCE_CUSTOM_DRAW = 1u << 3,
    OBS_SOURCE_INTERACTION = 1u << 5,
};

enum obs_text_type : int {
    OBS_TEXT_DEFAULT = 0,
    OBS_TEXT_PASSWORD = 1,
    OBS_TEXT_MULTILINE = 2,
    OBS_TEXT_INFO = 3,
};

enum obs_path_type : int {
    OBS_PATH_FILE = 0,
    OBS_PATH_FILE_SAVE = 1,
    OBS_PATH_DIRECTORY = 2,
};

enum obs_combo_type : int {
    OBS_COMBO_TYPE_INVALID = 0,
    OBS_COMBO_TYPE_EDITABLE = 1,
    OBS_COMBO_TYPE_LIST = 2,
};

enum obs_combo_format : int {
    OBS_COMBO_FORMAT_INVALID = 0,
    OBS_COMBO_FORMAT_INT = 1,
    OBS_COMBO_FORMAT_FLOAT = 2,
    OBS_COMBO_FORMAT_STRING = 3,
    OBS_COMBO_FORMAT_BOOL = 4,
};

enum obs_group_type : int {
    OBS_GROUP_NORMAL = 0,
    OBS_GROUP_CHECKABLE = 1,
};

using obs_property_clicked_t = bool (*)(obs_properties_t *props, obs_property_t *property, void *data);

// OBS 当前通过 obs_register_source_s(info, size) 做结构体版本兼容。
// 下面字段顺序按已捕获到的原 DLL source_info 头部布局：
//   id @ 0x00, type/flags @ 0x08/0x0c, get_name @ 0x10,
//   create @ 0x18, destroy @ 0x20, get_properties @ 0x40。
struct obs_source_info_lite {
    const char *id;
    obs_source_type type;
    std::uint32_t output_flags;
    const char *(*get_name)(void *type_data);
    void *(*create)(obs_data_t *settings, obs_source_t *source);
    void (*destroy)(void *data);
    std::uint32_t (*get_width)(void *data);
    std::uint32_t (*get_height)(void *data);
    void (*get_defaults)(obs_data_t *settings);
    obs_properties_t *(*get_properties)(void *data);
    void (*update)(void *data, obs_data_t *settings);
};

static_assert(offsetof(obs_source_info_lite, id) == 0x00);
static_assert(offsetof(obs_source_info_lite, type) == 0x08);
static_assert(offsetof(obs_source_info_lite, get_name) == 0x10);
static_assert(offsetof(obs_source_info_lite, create) == 0x18);
static_assert(offsetof(obs_source_info_lite, destroy) == 0x20);
static_assert(offsetof(obs_source_info_lite, get_defaults) == 0x38);
static_assert(offsetof(obs_source_info_lite, get_properties) == 0x40);

