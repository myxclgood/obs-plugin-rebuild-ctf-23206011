#pragma once

#include "config.h"
#include <windows.h>
#include <string>

class MouseController {
public:
    MouseController() = default;
    ~MouseController();

    bool move_relative(int dx, int dy, const RuntimeConfig &config);

private:
    bool move_sendinput(int dx, int dy);
    bool move_kmbox_serial(int dx, int dy, const RuntimeConfig &config);
    bool ensure_serial(const std::string &port);
    void close_serial();

    HANDLE serial_ = INVALID_HANDLE_VALUE;
    std::string opened_port_;
};
