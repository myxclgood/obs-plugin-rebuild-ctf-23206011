#pragma once

#include <string>

struct obs_data;
using obs_data_t = obs_data;

struct RuntimeConfig {
    std::string weights_path;
    double conf_threshold = 0.35;
    int yoloversion = 1;
    int first_part = 0;
    int include_head = 0;
    int first_team = 0;
    int mouse_move_method = 0;
    std::string kmbox_vid_pid;
    int inference_method = 0;
    int cpu_threads = 3;
    bool half_precision = false;
    int gpu_index = -1;
    int screenshot_mode = 0;
    bool show_detection_window = false;

    double game_sensitivity = 1.0;
    int mouse_single_movement_distance = 100;
    double movement_shake_degree = 0.0;
    int maximum_lead = 1000;
    int lead_gear = 0;
    int game_rotation_pixel_count = 3750;
    double rotation_measurement_sensitivity = 1.0;

    int rifle_delay_compensation_time = 20;
    int rifle_aim_key_value = 0;
    int rifle_aim_key_value2 = 0;
    int rifle_aim_mode = 1;
    int rifle_automatic_fire_interval = 80;
    double rifle_automatic_fire_judgment_range = 0.5;
    int rifle_aim_pixel_range = 100;
    int rifle_aim_position_upper_limit = 1;
    int rifle_aim_position_lower_limit = 2;
    int rifle_aim_position_horizontal_limit = 1;
    double rifle_static_aim_speed = 1.0;
    double rifle_movement_tracking_speed = 1.0;
};

struct ObsApi;

RuntimeConfig read_config_from_obs(ObsApi &obs, obs_data_t *settings);
