#pragma once

#include "obs_abi_min.h"
#include <windows.h>

struct ObsApi {
    HMODULE obs = nullptr;

    void (*obs_register_source_s)(const obs_source_info_lite *info, std::size_t size) = nullptr;

    obs_properties_t *(*obs_properties_create)() = nullptr;
    void (*obs_properties_destroy)(obs_properties_t *props) = nullptr;

    obs_property_t *(*obs_properties_add_bool)(obs_properties_t *, const char *, const char *) = nullptr;
    obs_property_t *(*obs_properties_add_int)(obs_properties_t *, const char *, const char *, int, int, int) = nullptr;
    obs_property_t *(*obs_properties_add_int_slider)(obs_properties_t *, const char *, const char *, int, int, int) = nullptr;
    obs_property_t *(*obs_properties_add_float)(obs_properties_t *, const char *, const char *, double, double, double) = nullptr;
    obs_property_t *(*obs_properties_add_float_slider)(obs_properties_t *, const char *, const char *, double, double, double) = nullptr;
    obs_property_t *(*obs_properties_add_text)(obs_properties_t *, const char *, const char *, obs_text_type) = nullptr;
    obs_property_t *(*obs_properties_add_path)(obs_properties_t *, const char *, const char *, obs_path_type, const char *, const char *) = nullptr;
    obs_property_t *(*obs_properties_add_list)(obs_properties_t *, const char *, const char *, obs_combo_type, obs_combo_format) = nullptr;
    obs_property_t *(*obs_properties_add_button)(obs_properties_t *, const char *, const char *, obs_property_clicked_t) = nullptr;
    obs_property_t *(*obs_properties_add_group)(obs_properties_t *, const char *, const char *, obs_group_type, obs_properties_t *) = nullptr;

    void (*obs_property_set_visible)(obs_property_t *, bool) = nullptr;
    void (*obs_property_int_set_suffix)(obs_property_t *, const char *) = nullptr;
    void (*obs_property_list_add_int)(obs_property_t *, const char *, long long) = nullptr;

    void (*obs_data_set_default_bool)(obs_data_t *, const char *, bool) = nullptr;
    void (*obs_data_set_default_int)(obs_data_t *, const char *, long long) = nullptr;
    void (*obs_data_set_default_double)(obs_data_t *, const char *, double) = nullptr;
    const char *(*obs_data_get_string)(obs_data_t *, const char *) = nullptr;
    long long (*obs_data_get_int)(obs_data_t *, const char *) = nullptr;
    double (*obs_data_get_double)(obs_data_t *, const char *) = nullptr;
    bool (*obs_data_get_bool)(obs_data_t *, const char *) = nullptr;

    template <typename T>
    bool bind(T &slot, const char *name)
    {
        slot = reinterpret_cast<T>(GetProcAddress(obs, name));
        return slot != nullptr;
    }

    bool load()
    {
        if (obs)
            return true;
        obs = GetModuleHandleW(L"obs.dll");
        if (!obs)
            obs = LoadLibraryW(L"obs.dll");
        if (!obs)
            return false;

        bool ok = true;
        ok &= bind(obs_register_source_s, "obs_register_source_s");
        ok &= bind(obs_properties_create, "obs_properties_create");
        bind(obs_properties_destroy, "obs_properties_destroy");
        ok &= bind(obs_properties_add_bool, "obs_properties_add_bool");
        ok &= bind(obs_properties_add_int, "obs_properties_add_int");
        ok &= bind(obs_properties_add_int_slider, "obs_properties_add_int_slider");
        ok &= bind(obs_properties_add_float, "obs_properties_add_float");
        ok &= bind(obs_properties_add_float_slider, "obs_properties_add_float_slider");
        ok &= bind(obs_properties_add_text, "obs_properties_add_text");
        ok &= bind(obs_properties_add_path, "obs_properties_add_path");
        ok &= bind(obs_properties_add_list, "obs_properties_add_list");
        ok &= bind(obs_properties_add_button, "obs_properties_add_button");
        ok &= bind(obs_properties_add_group, "obs_properties_add_group");
        bind(obs_property_set_visible, "obs_property_set_visible");
        bind(obs_property_int_set_suffix, "obs_property_int_set_suffix");
        ok &= bind(obs_property_list_add_int, "obs_property_list_add_int");
        bind(obs_data_set_default_bool, "obs_data_set_default_bool");
        bind(obs_data_set_default_int, "obs_data_set_default_int");
        bind(obs_data_set_default_double, "obs_data_set_default_double");
        bind(obs_data_get_string, "obs_data_get_string");
        bind(obs_data_get_int, "obs_data_get_int");
        bind(obs_data_get_double, "obs_data_get_double");
        bind(obs_data_get_bool, "obs_data_get_bool");
        return ok;
    }
};
