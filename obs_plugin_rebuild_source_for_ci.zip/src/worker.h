#pragma once

#include "config.h"
#include "capture_manager.h"
#include "detector.h"
#include "mouse_controller.h"

#include <atomic>
#include <mutex>
#include <thread>

class AimWorker {
public:
    ~AimWorker();

    void update_config(const RuntimeConfig &config);
    void start();
    void stop();
    bool running() const { return running_.load(); }

private:
    void loop();
    bool aim_key_down(const RuntimeConfig &config) const;

    mutable std::mutex mutex_;
    RuntimeConfig config_;
    std::atomic<bool> running_{false};
    std::thread thread_;
    CaptureManager capturer_;
    DetectorRuntime detector_;
    MouseController mouse_;
};
