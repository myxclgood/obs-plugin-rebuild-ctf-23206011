#pragma once

#include "config.h"
#include "detector_opencv_dnn.h"

#if OBS_REBUILD_WITH_OPENCV && OBS_REBUILD_WITH_ONNXRUNTIME
#include <onnxruntime_cxx_api.h>
#include <opencv2/core.hpp>
#include <memory>
#include <optional>
#include <string>
#include <vector>

class DetectorOnnxRuntime {
public:
    DetectorOnnxRuntime();
    bool configure(const RuntimeConfig &config);
    bool ready() const { return ready_; }
    std::optional<DetectionResult> detect(const cv::Mat &bgr, const RuntimeConfig &config);

private:
    std::wstring widen_utf8(const std::string &s) const;

    Ort::Env env_;
    Ort::MemoryInfo memory_info_;
    std::unique_ptr<Ort::Session> session_;
    std::string loaded_model_;
    std::string input_name_;
    std::vector<std::string> output_names_store_;
    std::vector<const char *> output_names_;
    int input_w_ = 640;
    int input_h_ = 640;
    bool ready_ = false;
};
#else
class DetectorOnnxRuntime {
public:
    bool configure(const RuntimeConfig &) { return false; }
    bool ready() const { return false; }
};
#endif
