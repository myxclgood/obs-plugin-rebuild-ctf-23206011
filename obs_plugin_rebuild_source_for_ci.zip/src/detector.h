#pragma once

#include "config.h"
#include "detector_opencv_dnn.h"
#include "detector_onnxruntime.h"

#if OBS_REBUILD_WITH_OPENCV
#include <opencv2/core.hpp>
#include <optional>

class DetectorRuntime {
public:
    bool configure(const RuntimeConfig &config);
    bool ready() const;
    std::optional<DetectionResult> detect(const cv::Mat &bgr, const RuntimeConfig &config);

private:
    DetectorOpenCVDnn opencv_;
    DetectorOnnxRuntime ort_;
    bool prefer_ort_ = false;
};
#endif
