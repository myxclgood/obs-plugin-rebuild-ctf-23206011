#include "detector_onnxruntime.h"

#if OBS_REBUILD_WITH_OPENCV && OBS_REBUILD_WITH_ONNXRUNTIME
#include <windows.h>
#include <opencv2/dnn.hpp>
#include <opencv2/imgproc.hpp>
#include <algorithm>
#include <cmath>
#include <filesystem>

#if OBS_REBUILD_WITH_DIRECTML
extern "C" OrtStatus *ORT_API_CALL OrtSessionOptionsAppendExecutionProvider_DML(OrtSessionOptions *options, int device_id);
#endif

DetectorOnnxRuntime::DetectorOnnxRuntime()
    : env_(ORT_LOGGING_LEVEL_WARNING, "obs_plugin_rebuild"),
      memory_info_(Ort::MemoryInfo::CreateCpu(OrtArenaAllocator, OrtMemTypeDefault))
{
}

std::wstring DetectorOnnxRuntime::widen_utf8(const std::string &s) const
{
    if (s.empty())
        return {};
    int n = MultiByteToWideChar(CP_UTF8, 0, s.c_str(), -1, nullptr, 0);
    if (n <= 0)
        return std::wstring(s.begin(), s.end());
    std::wstring out(static_cast<size_t>(n - 1), L'\0');
    MultiByteToWideChar(CP_UTF8, 0, s.c_str(), -1, out.data(), n);
    return out;
}

bool DetectorOnnxRuntime::configure(const RuntimeConfig &config)
{
    if (config.weights_path.empty() || !std::filesystem::exists(config.weights_path)) {
        ready_ = false;
        session_.reset();
        loaded_model_.clear();
        return false;
    }
    if (ready_ && loaded_model_ == config.weights_path)
        return true;

    try {
        Ort::SessionOptions options;
        options.SetIntraOpNumThreads(std::max(1, config.cpu_threads));
        options.SetGraphOptimizationLevel(GraphOptimizationLevel::ORT_ENABLE_EXTENDED);

#if OBS_REBUILD_WITH_DIRECTML
        if (config.inference_method == 1) {
            OrtStatus *st = OrtSessionOptionsAppendExecutionProvider_DML(options, config.gpu_index < 0 ? 0 : config.gpu_index);
            if (st) {
                Ort::GetApi().ReleaseStatus(st);
            }
        }
#endif

        auto path = widen_utf8(config.weights_path);
        session_ = std::make_unique<Ort::Session>(env_, path.c_str(), options);
        Ort::AllocatorWithDefaultOptions allocator;
        auto input_name = session_->GetInputNameAllocated(0, allocator);
        input_name_ = input_name.get() ? input_name.get() : "images";

        auto type_info = session_->GetInputTypeInfo(0).GetTensorTypeAndShapeInfo();
        auto shape = type_info.GetShape();
        if (shape.size() >= 4) {
            if (shape[2] > 0) input_h_ = static_cast<int>(shape[2]);
            if (shape[3] > 0) input_w_ = static_cast<int>(shape[3]);
        }
        if (input_w_ <= 0 || input_h_ <= 0) {
            input_w_ = 640;
            input_h_ = 640;
        }

        output_names_store_.clear();
        output_names_.clear();
        size_t out_count = session_->GetOutputCount();
        for (size_t i = 0; i < out_count; ++i) {
            auto out_name = session_->GetOutputNameAllocated(i, allocator);
            output_names_store_.push_back(out_name.get() ? out_name.get() : "output");
        }
        for (auto &n : output_names_store_)
            output_names_.push_back(n.c_str());

        loaded_model_ = config.weights_path;
        ready_ = true;
        return true;
    } catch (...) {
        ready_ = false;
        session_.reset();
        loaded_model_.clear();
        return false;
    }
}

std::optional<DetectionResult> DetectorOnnxRuntime::detect(const cv::Mat &bgr, const RuntimeConfig &config)
{
    if (!ready_ || !session_ || bgr.empty())
        return std::nullopt;

    cv::Mat blob;
    cv::dnn::blobFromImage(bgr, blob, 1.0 / 255.0, cv::Size(input_w_, input_h_), cv::Scalar(), true, false);
    std::vector<int64_t> input_shape{1, 3, input_h_, input_w_};
    size_t tensor_size = static_cast<size_t>(blob.total());
    Ort::Value input_tensor = Ort::Value::CreateTensor<float>(
        memory_info_, reinterpret_cast<float *>(blob.data), tensor_size, input_shape.data(), input_shape.size());

    const char *input_names[] = {input_name_.c_str()};
    std::vector<Ort::Value> outputs;
    try {
        outputs = session_->Run(Ort::RunOptions{nullptr}, input_names, &input_tensor, 1,
                                output_names_.data(), output_names_.size());
    } catch (...) {
        return std::nullopt;
    }
    if (outputs.empty() || !outputs[0].IsTensor())
        return std::nullopt;

    auto info = outputs[0].GetTensorTypeAndShapeInfo();
    auto shape = info.GetShape();
    const float *data = outputs[0].GetTensorData<float>();
    if (!data || shape.size() < 3)
        return std::nullopt;

    int d1 = static_cast<int>(shape[1]);
    int d2 = static_cast<int>(shape[2]);
    bool transposed = false;
    int rows = d1;
    int cols = d2;
    if (d1 < d2 && d1 <= 256) {
        transposed = true;
        rows = d2;
        cols = d1;
    }
    if (cols < 5)
        return std::nullopt;

    auto at = [&](int r, int c) -> float {
        if (transposed)
            return data[c * rows + r];
        return data[r * cols + c];
    };

    float xscale = static_cast<float>(bgr.cols) / static_cast<float>(input_w_);
    float yscale = static_cast<float>(bgr.rows) / static_cast<float>(input_h_);
    float threshold = static_cast<float>(config.conf_threshold);

    DetectionResult best;
    float best_score = 0.0f;
    for (int r = 0; r < rows; ++r) {
        float cx = at(r, 0), cy = at(r, 1), w = at(r, 2), h = at(r, 3);
        float objectness = 1.0f;
        int class_begin = 4;
        if (cols > 6) {
            float obj = at(r, 4);
            if (obj >= 0.0f && obj <= 1.0f) {
                objectness = obj;
                class_begin = 5;
            }
        }
        int cls = -1;
        float cls_score = 0.0f;
        for (int c = class_begin; c < cols; ++c) {
            float s = at(r, c);
            if (s > cls_score) {
                cls_score = s;
                cls = c - class_begin;
            }
        }
        float score = objectness * cls_score;
        if (score < threshold || score <= best_score)
            continue;
        int left = static_cast<int>((cx - w * 0.5f) * xscale);
        int top = static_cast<int>((cy - h * 0.5f) * yscale);
        int bw = static_cast<int>(w * xscale);
        int bh = static_cast<int>(h * yscale);
        best.class_id = cls;
        best.confidence = score;
        best.box = cv::Rect(left, top, bw, bh) & cv::Rect(0, 0, bgr.cols, bgr.rows);
        best_score = score;
    }

    if (best_score <= 0.0f)
        return std::nullopt;
    return best;
}
#endif
