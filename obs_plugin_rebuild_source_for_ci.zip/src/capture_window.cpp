#include "capture_window.h"

#include <windows.h>

#if OBS_REBUILD_WITH_OPENCV
#include <opencv2/imgproc.hpp>

cv::Mat WindowCapturer::capture_foreground_bgr() const
{
    HWND hwnd = GetForegroundWindow();
    if (!hwnd)
        return {};
    RECT rc{};
    if (!GetWindowRect(hwnd, &rc))
        return {};
    int w = rc.right - rc.left;
    int h = rc.bottom - rc.top;
    if (w <= 0 || h <= 0)
        return {};

    HDC wnd = GetWindowDC(hwnd);
    if (!wnd)
        return {};
    HDC mem = CreateCompatibleDC(wnd);
    if (!mem) {
        ReleaseDC(hwnd, wnd);
        return {};
    }

    BITMAPINFO bi{};
    bi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
    bi.bmiHeader.biWidth = w;
    bi.bmiHeader.biHeight = -h;
    bi.bmiHeader.biPlanes = 1;
    bi.bmiHeader.biBitCount = 32;
    bi.bmiHeader.biCompression = BI_RGB;

    void *bits = nullptr;
    HBITMAP bmp = CreateDIBSection(wnd, &bi, DIB_RGB_COLORS, &bits, nullptr, 0);
    if (!bmp || !bits) {
        if (bmp) DeleteObject(bmp);
        DeleteDC(mem);
        ReleaseDC(hwnd, wnd);
        return {};
    }

    HGDIOBJ old = SelectObject(mem, bmp);
    BOOL ok = PrintWindow(hwnd, mem, PW_RENDERFULLCONTENT);
    if (!ok)
        BitBlt(mem, 0, 0, w, h, wnd, 0, 0, SRCCOPY | CAPTUREBLT);

    cv::Mat bgra(h, w, CV_8UC4, bits);
    cv::Mat bgr;
    cv::cvtColor(bgra, bgr, cv::COLOR_BGRA2BGR);

    SelectObject(mem, old);
    DeleteObject(bmp);
    DeleteDC(mem);
    ReleaseDC(hwnd, wnd);
    return bgr;
}
#endif
