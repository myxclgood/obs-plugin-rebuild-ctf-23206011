#include "capture_dxgi.h"

#if OBS_REBUILD_WITH_OPENCV
#include <opencv2/imgproc.hpp>`r`n#include <cstring>
#endif

bool DxgiScreenCapturer::init()
{
    if (duplication_)
        return true;

    UINT flags = D3D11_CREATE_DEVICE_BGRA_SUPPORT;
#ifdef _DEBUG
    flags |= D3D11_CREATE_DEVICE_DEBUG;
#endif
    D3D_FEATURE_LEVEL levels[] = {D3D_FEATURE_LEVEL_11_1, D3D_FEATURE_LEVEL_11_0, D3D_FEATURE_LEVEL_10_1};
    D3D_FEATURE_LEVEL got{};
    HRESULT hr = D3D11CreateDevice(nullptr, D3D_DRIVER_TYPE_HARDWARE, nullptr, flags,
                                   levels, ARRAYSIZE(levels), D3D11_SDK_VERSION,
                                   &device_, &got, &context_);
    if (FAILED(hr))
        return false;

    Microsoft::WRL::ComPtr<IDXGIDevice> dxgi_device;
    hr = device_.As(&dxgi_device);
    if (FAILED(hr))
        return false;

    Microsoft::WRL::ComPtr<IDXGIAdapter> adapter;
    hr = dxgi_device->GetAdapter(&adapter);
    if (FAILED(hr))
        return false;

    Microsoft::WRL::ComPtr<IDXGIOutput> output;
    hr = adapter->EnumOutputs(0, &output);
    if (FAILED(hr))
        return false;

    Microsoft::WRL::ComPtr<IDXGIOutput1> output1;
    hr = output.As(&output1);
    if (FAILED(hr))
        return false;

    hr = output1->DuplicateOutput(device_.Get(), &duplication_);
    if (FAILED(hr)) {
        reset();
        return false;
    }
    return true;
}

void DxgiScreenCapturer::reset()
{
    staging_.Reset();
    duplication_.Reset();
    context_.Reset();
    device_.Reset();
    width_ = 0;
    height_ = 0;
}

#if OBS_REBUILD_WITH_OPENCV
cv::Mat DxgiScreenCapturer::capture_bgr(unsigned timeout_ms)
{
    if (!init())
        return {};

    DXGI_OUTDUPL_FRAME_INFO info{};
    Microsoft::WRL::ComPtr<IDXGIResource> resource;
    HRESULT hr = duplication_->AcquireNextFrame(timeout_ms, &info, &resource);
    if (hr == DXGI_ERROR_WAIT_TIMEOUT)
        return {};
    if (hr == DXGI_ERROR_ACCESS_LOST || hr == DXGI_ERROR_INVALID_CALL) {
        reset();
        return {};
    }
    if (FAILED(hr))
        return {};

    Microsoft::WRL::ComPtr<ID3D11Texture2D> tex;
    hr = resource.As(&tex);
    if (FAILED(hr)) {
        duplication_->ReleaseFrame();
        return {};
    }

    D3D11_TEXTURE2D_DESC desc{};
    tex->GetDesc(&desc);
    if (!staging_ || width_ != static_cast<int>(desc.Width) || height_ != static_cast<int>(desc.Height)) {
        width_ = static_cast<int>(desc.Width);
        height_ = static_cast<int>(desc.Height);
        D3D11_TEXTURE2D_DESC sd = desc;
        sd.BindFlags = 0;
        sd.MiscFlags = 0;
        sd.CPUAccessFlags = D3D11_CPU_ACCESS_READ;
        sd.Usage = D3D11_USAGE_STAGING;
        staging_.Reset();
        hr = device_->CreateTexture2D(&sd, nullptr, &staging_);
        if (FAILED(hr)) {
            duplication_->ReleaseFrame();
            return {};
        }
    }

    context_->CopyResource(staging_.Get(), tex.Get());
    D3D11_MAPPED_SUBRESOURCE mapped{};
    hr = context_->Map(staging_.Get(), 0, D3D11_MAP_READ, 0, &mapped);
    if (FAILED(hr)) {
        duplication_->ReleaseFrame();
        return {};
    }

    cv::Mat bgra(height_, width_, CV_8UC4);
    for (int y = 0; y < height_; ++y) {
        const auto *src = static_cast<const unsigned char *>(mapped.pData) + y * mapped.RowPitch;
        std::memcpy(bgra.ptr(y), src, static_cast<size_t>(width_) * 4);
    }
    context_->Unmap(staging_.Get(), 0);
    duplication_->ReleaseFrame();

    cv::Mat bgr;
    cv::cvtColor(bgra, bgr, cv::COLOR_BGRA2BGR);
    return bgr;
}
#endif

