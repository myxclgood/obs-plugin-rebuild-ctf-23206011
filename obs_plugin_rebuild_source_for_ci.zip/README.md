# obs_plugin_rebuild

这是“方案 D”的干净重写工程：不嵌入、不释放、不转发原始 `obs_plugin.dll` core。

目标：

- 生成单文件 `obs_plugin.dll`。
- 保留 OBS source id：`obs plugin`。
- 保留基础配置、rifle 配置、ONNX/OpenCV 检测、截图、鼠标控制的可运行逻辑。
- 删除 `sniper_rifle_parameter_settings`、`sniper_head`、`sniper_body` 及相关 UI。
- 不携带原始受保护 DLL 的代码/壳/资源。

## 已补模块

- OpenCV DNN ONNX 推理 fallback：`src/detector_opencv_dnn.cpp`
- ONNXRuntime C++ API 推理：`src/detector_onnxruntime.cpp`
- DirectML EP 可选接入：`OBS_REBUILD_WITH_DIRECTML`
- GDI 全屏截图：`src/capture_gdi.cpp`
- 前台窗口截图：`src/capture_window.cpp`
- DXGI Desktop Duplication：`src/capture_dxgi.cpp`
- 截图模式调度：`src/capture_manager.cpp`
- SendInput 鼠标移动：`src/mouse_controller.cpp`
- kmbox 串口文本协议 fallback：`kmbox_vid_pid` 填 `COM3` 这类端口时发送 `km.move(x,y)`
- Start/Stop 后台线程：`src/worker.cpp`

## 仍不能 1:1 保证的原版细节

- kmboxA/kmboxA+/kmboxB 不同固件的私有协议可能不同；当前实现了常见串口文本命令。
- Logitech 驱动私有接口未内置，当前回退 SendInput。
- 武器图标/CSV/压枪项属于此前要求删除的 `sniper_rifle_parameter_settings` 相关块，未重新加入。
- 原版所有曲线/预测/热键写回细节无法从 C++ 二进制无损恢复，当前按配置项做近似实现。

## 构建依赖

当前这台机器未安装编译链。构建需要：

- Visual Studio Build Tools 2022 + Windows SDK
- CMake
- OpenCV 4.x，带 `dnn`，例如 `opencv_world480.lib/.dll`
- 可选：ONNX Runtime dev 包，含 `include` 和 `lib\onnxruntime.lib`

## CMake 构建

只用 OpenCV DNN：

```powershell
cd D:\yanjiu\obs_plugin_rebuild
.\build_msvc.ps1 -OpenCV_DIR C:\opencv\build
```

启用 ONNXRuntime：

```powershell
cmake -S D:\yanjiu\obs_plugin_rebuild -B D:\yanjiu\obs_plugin_rebuild\build-msvc -A x64 `
  -DOpenCV_DIR=C:\opencv\build `
  -DOBS_REBUILD_WITH_ONNXRUNTIME=ON `
  -DONNXRUNTIME_ROOT=C:\onnxruntime
cmake --build D:\yanjiu\obs_plugin_rebuild\build-msvc --config Release
```

启用 DirectML：

```powershell
cmake -S D:\yanjiu\obs_plugin_rebuild -B D:\yanjiu\obs_plugin_rebuild\build-msvc -A x64 `
  -DOpenCV_DIR=C:\opencv\build `
  -DOBS_REBUILD_WITH_ONNXRUNTIME=ON `
  -DOBS_REBUILD_WITH_DIRECTML=ON `
  -DONNXRUNTIME_ROOT=C:\onnxruntime
cmake --build D:\yanjiu\obs_plugin_rebuild\build-msvc --config Release
```

输出：

```text
D:\yanjiu\obs_plugin_rebuild\build-msvc\Release\obs_plugin.dll
```

## cl 直接构建

```powershell
cd D:\yanjiu\obs_plugin_rebuild
.\build_cl.ps1 `
  -OpenCVInclude C:\opencv\build\include `
  -OpenCVLib C:\opencv\build\x64\vc16\lib `
  -OpenCVWorldLib opencv_world480.lib
```

带 ONNXRuntime：

```powershell
.\build_cl.ps1 `
  -OpenCVInclude C:\opencv\build\include `
  -OpenCVLib C:\opencv\build\x64\vc16\lib `
  -OpenCVWorldLib opencv_world480.lib `
  -WithOnnxRuntime `
  -OnnxRuntimeInclude C:\onnxruntime\include `
  -OnnxRuntimeLib C:\onnxruntime\lib
```

## 运行依赖

构建出的 `obs_plugin.dll` 是单文件插件，但运行时仍需要第三方运行库能被 Windows 找到：

```text
opencv_world480.dll
onnxruntime.dll    # 仅启用 ONNXRuntime 时
```

这些是依赖库，不是原始 core。

## 验证移除项

```powershell
.\scripts\verify_removed_strings.ps1 .\build-msvc\Release\obs_plugin.dll
```
