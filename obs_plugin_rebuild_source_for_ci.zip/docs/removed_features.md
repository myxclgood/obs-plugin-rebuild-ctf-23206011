# 已删除/未恢复项目

目标：重建一个不包含 `sniper_rifle_parameter_settings` 相关 UI 和功能入口的精简版 OBS 插件工程。

## 已从精简工程中移除

### `sniper_rifle_parameter_settings`

根据运行时属性追踪，原 DLL 在 `obs_properties_add_group(..., "sniper_rifle_parameter_settings", ...)` 之前构建了这一组子属性。精简工程没有注册该组，也没有设置这些默认值：

- `sniper_delay_compensation_time`
- `sniper_aim_key`
- `sniper_aim_key_value`
- `capture_key_sniper`
- `sniper_aim_mode`
- `sniper_automatic_fire_delay`
- `sniper_automatic_fire_interval`
- `sniper_automatic_fire_judgment_range`
- `sniper_aim_pixel_range`
- `sniper_aim_position_upper_limit`
- `sniper_aim_position_lower_limit`
- `sniper_static_aim_speed`
- `sniper_movement_tracking_speed`

### `gun_control_settings`

之前定位出的 recoil/weapon-icon 配置与该功能块高度相关，精简工程也一并不注册：

- `aim_key_for_gun_control`
- `recoil_key_value`
- `capture_key_gun_control`
- `weapon_icon_recognition_mode`
- `weapon_icon_path`
- `weapon_csv_path`
- `weapon_icon_detection_color_limit_up`
- `weapon_icon_detection_color_limit_down`
- `normal_gun_control_value`
- `recoil_offset`
- `gun_control_settings`

### 热键信息

`start_and_info` 里与狙击相关的提示项也不再显示：

- `sniper_head`
- `sniper_body`

## 保留项目

- `basic_settings`
- `global_movement_parameters`
- `rifle_parameter_settings`
- `start_and_info` 中非 sniper 的提示与 Start/Stop 按钮

## 重要说明

这是 clean-room 精简工程骨架，不是 C++ 源码的无损还原。当前版本恢复的是 OBS 插件导出、source 注册和属性页结构；原 DLL 的 ONNX/OpenCV 推理、截图、鼠标控制等运行逻辑没有在此工程里重写。

